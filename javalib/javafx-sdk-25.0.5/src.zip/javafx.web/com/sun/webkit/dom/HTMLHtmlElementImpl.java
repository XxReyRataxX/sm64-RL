/*
 * Copyright (c) 2013, 2024, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.webkit.dom;

import org.w3c.dom.html.HTMLHtmlElement;

public class HTMLHtmlElementImpl extends HTMLElementImpl implements HTMLHtmlElement {
    HTMLHtmlElementImpl(long peer) {
        super(peer);
    }

    static HTMLHtmlElement getImpl(long peer) {
        return (HTMLHtmlElement)create(peer);
    }


// Attributes
    @Override
    public String getVersion() {
        return getVersionImpl(getPeer());
    }
    native static String getVersionImpl(long peer);

    @Override
    public void setVersion(String value) {
        setVersionImpl(getPeer(), value);
    }
    native static void setVersionImpl(long peer, String value);

    public String getManifest() {
        return getManifestImpl(getPeer());
    }
    native static String getManifestImpl(long peer);

    public void setManifest(String value) {
        setManifestImpl(getPeer(), value);
    }
    native static void setManifestImpl(long peer, String value);

}

